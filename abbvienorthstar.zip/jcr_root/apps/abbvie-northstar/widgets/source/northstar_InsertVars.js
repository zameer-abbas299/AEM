/**
 * @class CQ.form.rte.plugins.InsertVarsPlugin
 * @extends CQ.form.rte.plugins.Plugin
 * <p>The plugin ID is "<b>insertvars</b>".</p>
 * <p><b>Features</b></p>
 * <p><b>Additional config requirements</b></p>
 * <p>The following plugin-specific settings must be configured through the corresponding
 * {@link CQ.form.rte.EditorKernel} instance:</p>
 * <ul>
 *   <li>The variablesheets to be used must be provided through
 *     {@link CQ.form.RichText#externalStyleSheets}.</li>
 * </ul>
 */
CQ.form.rte.plugins.InsertVarsPlugin = CQ.Ext.extend(CQ.form.rte.plugins.Plugin, {   
    /**
     * @private
     */
    cachedVariables: null,

    /**
     * @private
     */
    variablesUI: null,

    constructor: function(editorKernel) {
        CQ.form.rte.plugins.InsertVarsPlugin.superclass.constructor.call(this, editorKernel);
    },
    
    getVariables: function() {
        var com = CQ.form.rte.Common;        
        if (!this.cachedVariables) {        	        	
        	var keynameopts = [];
        	var customrte = CQ.dtyb;
        	var optionsmap = customrte.getComboOptions();   
        	var optval = optionsmap.split(",");        	
        	for (var i=0; i < optval.length-1; i++)   {
        		if(optval[i] != null){
        			keynameopts.push({value: optval[i], text:optval[i]});
        		}        		
        	}
        	//CQ.Ext.Msg.alert('keynameopts', keynameopts);
        	
        	this.cachedVariables = keynameopts || { };
            com.removeJcrData(this.cachedVariables);
        }
        return this.cachedVariables;
    },

    initializeUI: function(tbGenerator) {
        var plg = CQ.form.rte.plugins;
        var ui = CQ.form.rte.ui;
        if (this.isFeatureEnabled("insertvars")) {
            this.variablesUI = new ui.TbVarSelector("insertvars", this, null, this.getVariables());
            tbGenerator.addElement("insertvars", plg.Plugin.SORT_STYLES, this.variablesUI, 10);
        }
    },    
    
    execute: function(cmdId) {
        if (!this.variablesUI) {
            return;
        }
        var cmd = null;
        var value = null;
        switch (cmdId.toLowerCase()) {
            case "insertvars_insert":
                cmd = "inserthtml";
                value = this.variablesUI.getSelectedVariable();
                break;
        }
        if (cmd && value) {
            var vt = "${"+value+"}";
            this.editorKernel.relayCmd(cmd, vt);
        }
    }
});

// register plugin
CQ.form.rte.plugins.PluginRegistry.register("insertvars", CQ.form.rte.plugins.InsertVarsPlugin);