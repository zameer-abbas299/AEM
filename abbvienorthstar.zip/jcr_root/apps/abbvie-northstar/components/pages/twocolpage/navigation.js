
"use strict";

use( function () {
var Constants = {

     title: "title",
     link: "link"
    };

    var title = properties.get(Constants.title);
    var link = properties.get(Constants.link);

    return {
        title: title,
        link: link

    };
});
