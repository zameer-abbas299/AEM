(function (document, $, ns) {
	"use strict";
     $(document).on("click", ".cq-dialog-submit", function (e) {

         if($('#abbvie-northstar-colcntrlId').hasClass('abbvie-northstar-colcntrlClass')){
                    e.stopPropagation();
                    e.preventDefault();
                    var $form = $(this).closest("form.foundation-form"),
                        message, clazz = "coral-Button ";
                    var width=0;
                    var expectedTotal = 100;            
                    /* Loop to Fetch individual multifield values and validate*/
					
                    $.each($("coral-numberinput[name='./columns']"), function (index, value) { 
                        width+=parseInt($(value).val());
                    });
            
                    if(width!==expectedTotal) {
                            ns.ui.helpers.prompt({
                            title: Granite.I18n.get("Validation Error"),
                            message: "Total width of all columns needs to be exactly 100 percent!",
                            actions: [{
                                id: "CANCEL",
                                text: "CANCEL",
                                className: "coral-Button"
                            }],
							callback: function (actionId) {
								if (actionId === "CANCEL") {
									}
								}
						});
					}
					else{
						$form.submit();
					}
			}
    });
})(document, Granite.$, Granite.author);