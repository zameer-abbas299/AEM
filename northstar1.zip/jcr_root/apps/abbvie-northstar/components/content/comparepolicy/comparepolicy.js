"use strict";
use( function () {

    var languagecheck=granite.resource.properties["newwindow"];
    var nodepaths=this.currentChild;
    var resourceResolver = resource.getResourceResolver();
    var resourceheader=resourceResolver.getResource(nodepaths+"/general");
	var hidelangdropdown=granite.resource.properties["hidelangdropdown"];
     return {
         resourceheader:resourceheader,
         nodepaths:nodepaths,
         languagecheck:languagecheck,
		 hidelangdropdown:hidelangdropdown
     };

});