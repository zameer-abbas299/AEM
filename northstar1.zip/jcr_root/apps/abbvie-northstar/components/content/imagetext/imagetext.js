"use strict";

use(function () {
             var outputlink;
             var selectedlink=properties.get("imagelink","");

if(selectedlink.includes("."))
{
    outputlink=selectedlink;
}
else{
    outputlink=selectedlink+".html";
}

return{

    OutputSelectedlink:outputlink


};
});
