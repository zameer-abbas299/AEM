"use strict";
use( function () {
    var pagespath=this.pagespath;
    langCountryCode=pagespath.split("/")[6];


     return {

         pagespath:pagespath,
         langCountryCode:langCountryCode,


     };

});