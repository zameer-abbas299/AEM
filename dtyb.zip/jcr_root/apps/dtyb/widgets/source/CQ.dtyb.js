
CQ.dtyb = {};

CQ.dtyb.PATH = null;

CQ.dtyb.optionValues = null;

CQ.dtyb.setCurrentNodePath = function(path) {
    this.PATH = path;
};

CQ.dtyb.getCurrentNodePath = function() {
    //CQ.Ext.Msg.alert('nodepath2', this.PATH)   
   return this.PATH;
};

CQ.dtyb.setComboOptions = function(optionValues) {
    this.optionValues = optionValues;
};

CQ.dtyb.getComboOptions = function() {       
   return this.optionValues;
};


