
/**
 * The <code>CQ.form.MultiField</code> class represents an editable list
 * of form fields for editing multi value properties.
 * 
 * @class CQ.form.MultiField
 * @extends CQ.form.CompositeField
 */
CQ.form.CustomMultiField = CQ.Ext.extend(CQ.form.CompositeField, {

    /**
     * @cfg {Object} listItems
     * The configuration options for the fields (optional).
     */
	listItems: null,
	
	numberOfItems: null,
    
	name: null,
    /**
     * Creates a new <code>CQ.form.MultiField</code>.
     * @constructor
     * @param {Object} config The config object
     */
        
    constructor: function(config) {
        var list = this;
        this.nextParName = 1;
        if (!config.name){
        	config.name = "./numberofitems";
        }
        this.name = config.name;
        if (!config.value){
        	config.value = 0;
        }
        if (!config.listItems) {
            config.listItems = {};
        }
        if (!config.listItems.xtype) {
            config.listItems.xtype = "customgenericlist";
        }     
        var items = new Array();

        this.numberOfItems = new CQ.Ext.form.Hidden({
            "name": config.name,
            "value": config.value
        });
        items.push(this.numberOfItems);

        
        this.listItems = config.listItems;
        if(config.readOnly) {
            //if component is defined as readOnly, appy this to all items
            config.listItems.readOnly = true;
        } else {
            items.push({
                "xtype":"button",
                "text":"+",
                "handler":function() {
                    list.addItem();
                }
            });
        }
        for (var i  = 0; i<this.listItems.length; i++){
        	if (this.listItems[i].autoDelete){
        		items.push({
        			"xtype":"hidden",
        			"name":this.listItems[i].name + CQ.Sling.DELETE_SUFFIX
        		});
        	}
        }       
        
        
        
        config = CQ.Util.applyDefaults(config, {
            "defaults":{
                "xtype":"custommultifielditem",
                "fieldConfig":config.listItems,
                "listItems": config.listItems
            },
            "items":[
                { 
                    "xtype":"panel",
                    "border":false,
                    "bodyStyle":"padding:4px",
                    "items":items
                }
            ]
        });
        CQ.form.CustomMultiField.superclass.constructor.call(this,config);
        if (this.defaults.listItems.regex) {
            // somehow regex get broken in this.defaults, so fix it
            this.defaults.listItems.regex = config.fieldConfig.regex;
        }
        
        this.addEvents(
            /**
             * @event change
             * Fires when the value is changed.
             * @param {CQ.form.MultiField} this
             * @param {Mixed} newValue The new value
             * @param {Mixed} oldValue The original value
             */
            "change"
        );
        
        
    },

    /**
     * Adds a new field to the widget.
     * @param value The value of the field
     */
    addItem: function(value) {
        var item = this.insert(this.items.getCount() - 1, {});
        //this.setNumberOfItems();
        this.findParentByType("form").getForm().add(item.field);
        var obj = this.findParentByType("form");
        var forms = obj.getForm();
        for (var c in obj){
        //	alert(c);
        }
        this.doLayout();
        this.setNumberOfItems();
        return item;
   
    },
    
    getNumberOfItems: function(){
    	return this.items.getCount() - 1;
    	
    },
    
    setNumberOfItems: function(num){
    	if (!num){
    		this.numberOfItems.setValue(this.getNumberOfItems()); 
    	}
    	else{
    		this.numberOfItems.setValue(num);
    	}
    },
    

    processRecord: function(record, path) {                   	
    	var oldItems = this.items;
    	var values = new Array();
        oldItems.each(function(item/*, index, length*/) {
            if (item instanceof CQ.form.CustomMultiField.Item) {
                this.remove(item, true);
                this.findParentByType("form").getForm().remove(item);
            }
        }, this);                 
        
                
        var numItems = record.get(this.name);        
        if (!numItems){
        	numItems = 0;
        }
        
        if (numItems==1){
        		var item = this.addItem();
        		item.processRecord(record, path);
        }        
        else{
        	for (var i =0; i < numItems; i++){
        		var newRecord = record.copy();
        		for (c in newRecord.data){
        			
        			if (CQ.Ext.isArray(newRecord.data[c])){
        				newRecord.data[c] = newRecord.data[c][i];
        				
        			}
        		}
        		var item = this.addItem();
        		item.processRecord(newRecord, path);
        	}
        }
        	
                
    	
    },    

    getValue: function() {
        var value = new Array();
        this.items.each(function(item, index/*, length*/) {
            if (item instanceof CQ.form.MultiField.Item) {
                value[index] = item.getValue();
                index++;
            }
        }, this);
        return value;
    },
    
    /**
     * Sets a data value into the field and validates it.
     * @param {Mixed} value The value to set
     */
    setValue: function(value) {
        this.fireEvent("change", this, value, this.getValue());    	
        this.doLayout();
        if ((value != null) && (value != "")) {
            	this.addItem(value);        
        }
    }

});

CQ.Ext.reg("custommultifield", CQ.form.CustomMultiField);

/**
 * The <code>CQ.form.MultiField.Item</code> class represents an item in a
 * <code>CQ.form.MultiField</code>. This class is not intended for direct use.
 *
 * @private
 * @class CQ.form.MultiField.Item
 * @extends CQ.Ext.Panel
 */
CQ.form.CustomMultiField.Item = CQ.Ext.extend(CQ.Ext.Panel, {

    /**
     * Creates a new <code>CQ.form.MultiField.Item</code>.
     * @constructor
     * @param {Object} config The config object
     */
    constructor: function(config) {
        var item = this;
        this.field = CQ.Util.build(config.listItems, true);

        var items = new Array();
        items.push({
            "xtype":"panel",
            "border":false,
            "items":this.field
        });

        if(!config.fieldConfig.readOnly) {
            items.push({
                "xtype":"panel",
                "border":false,
                "items":{
                    "xtype":"button",
                    "text":"Up",
                    "handler":function() {
                        var parent = item.ownerCt;
                        var index = parent.items.indexOf(item);

                        if (index > 0) {
                            item.reorder(parent.items.itemAt(index - 1));
                        }
                    }
                }
            });
            items.push({
                "xtype":"panel",
                "border":false,
                "items":{
                    "xtype":"button",
                    "text":"Down",
                    "handler":function() {
                        var parent = item.ownerCt;
                        var index = parent.items.indexOf(item);

                        if (index < parent.items.getCount() - 1) {
                            item.reorder(parent.items.itemAt(index + 1));
                        }
                    }
                }
            });
            items.push({
                "xtype":"panel",
                "border":false,
                "items":{
                    "xtype":"button",
                    "text":"-",
                    "handler":function() {
            			var foobar = item.ownerCt.items.getCount() - 1;//The add button is an extra item
            			item.ownerCt.setNumberOfItems(item.ownerCt.getNumberOfItems() - 1);	
            			item.ownerCt.remove(item);
                			
            	}
                }
            });
        }

        config = CQ.Util.applyDefaults(config, {
            "layout":"table",
            "border":false,
            "layoutConfig":{
                "columns":4
            },
            "defaults":{
                "bodyStyle":"padding:20px"
            },
            "items":items
        });
        CQ.form.CustomMultiField.Item.superclass.constructor.call(this, config);

        if (config.value) {
            this.field.setValue(config.value);
        }
    },

    /**
     * Reorders the item above the specified item.
     * @param item The item to reorder above
     */
    reorder: function(item) {
        var value = item.field.getValue();
        item.field.setValue(this.field.getValue());
        this.field.setValue(value);
    },
    
    processRecord : function(record, path){
    	this.field.processRecord(record, path);
    },
        
    
    /**
     * Returns the data value.
     * @return {String} value The field value
     */
    getValue: function() {
        return this.field.getValue();
    },
    
    /**
     * Sets a data value into the field and validates it.
     * @param {String} value The value to set
     */
    setValue: function(value) {
        this.field.setValue(value);
    },
    
    setParName: function(value){
    	this.field.setParName(value);
    }
});

CQ.Ext.reg("custommultifielditem", CQ.form.CustomMultiField.Item);
